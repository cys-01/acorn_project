# Day 3

Notes: •  필수데이터, 사이드 데이터 크롤링
Task: 크롤링 진행