# Day 9

Start: 2025년 5월 12일
Task: 발표 리허설